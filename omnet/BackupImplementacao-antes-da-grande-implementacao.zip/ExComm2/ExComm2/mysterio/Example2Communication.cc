#include "../../ExComm2/mysterio/Example2Communication.h"

namespace mysterio {

Example2Communication::Example2Communication() {
    // TODO Auto-generated constructor stub

}

Example2Communication::~Example2Communication() {
    // TODO Auto-generated destructor stub
}

} /* namespace inet */
