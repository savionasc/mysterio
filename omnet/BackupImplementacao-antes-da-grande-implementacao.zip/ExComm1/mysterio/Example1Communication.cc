#include "Example1Communication.h"

namespace mysterio {

Example1Communication::Example1Communication() { }

Example1Communication::~Example1Communication() { }

}
