#ifndef MYSTERIO_OMNET_EXCOMM1_COMMUNICATION_UAVCOMMUNICATIONSOCKET_H_
#define MYSTERIO_OMNET_EXCOMM1_COMMUNICATION_UAVCOMMUNICATIONSOCKET_H_

#include "../../../src/communication/UAVCommunication.h"
#include "../../../src/utils/Message.h"

namespace mysterio {

class UAVCommunicationSocket : public UAVCommunication {
public:
    UAVCommunicationSocket();
    virtual ~UAVCommunicationSocket();

    //UAVCommunication
    void connectBase();
    void dispatchMessage(Message msg); //Aqui ele deve enviar mensagem pro Communication
    void disconnectBase();

    int  conexao();
    int  getSocketCode();
    bool isConnected();
    void setConnected(bool connected);
    void setSocketCode(int socketCode);

private:
    bool connected = false;
    int socketCode = -1;
};

}

#endif
